import os

# *****************************
# Environment specific settings
# *****************************

# DO NOT use "DEBUG = True" in production environments
DEBUG = True

SECRET_KEY = "\xd9\x8d\xc6,\xc0\xa7\xde!j\x0f\xd0\x81\xa9\xff\xe6\xae`v\x12\xa7\xd6/\tK"

# SQLAlchemy settings
SQLALCHEMY_DATABASE_URI = 'sqlite:///../app.sqlite'
SQLALCHEMY_TRACK_MODIFICATIONS = False    # Avoids a SQLAlchemy Warning

# Flask-Mail settings
# For smtp.gmail.com to work, you MUST set "Allow less secure apps" to ON in Google Accounts.
# Change it in https://myaccount.google.com/security#connectedapps (near the bottom).
MAIL_SERVER = 'smtp.gmail.com'
MAIL_PORT = 587
MAIL_USE_SSL = False
MAIL_USE_TLS = True
MAIL_USERNAME = 'jeremy.t.redd@gmail.com'
MAIL_PASSWORD = 'ankajjkgbrtiphfm'
#MAIL_PASSWORD = os.getenv(['MAIL_PASSWORD'])

# Sendgrid settings
SENDGRID_API_KEY='place-your-sendgrid-api-key-here'

# Flask-User settings
USER_APP_NAME = 'Flask-User starter app'
USER_EMAIL_SENDER_NAME = 'Jeremy Redd'
USER_EMAIL_SENDER_EMAIL = 'jeremy.t.redd@gmail.com'

ADMINS = [
    '"Admin One" <admin@jeremyredd.com>',
    ]
